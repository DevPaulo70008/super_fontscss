A rather rough interpretation of a font based on
the few letters supplied from a scan of the harry potter
book.

To actually type the words Harry Potter as it appears
on the book cover type the following

H   a   r   Alt0161   y
P   o   t   Alt0164   e    Alt0165

Alt0167 will save time by typing the word Potter whole.


All best

GM
